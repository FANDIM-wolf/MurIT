<?php
$config =  array('title' =>  'Mur It', 
    
    'vk_url' => 'http://vk.com/m.shishov99',


	'db'=>array(


	'server' => '127.0.0.1',
	'username' => 'root',
	'password' => '',
	'name' => 'mur' 
)
);

require "db.php";

?>